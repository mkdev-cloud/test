package com.dsa;

import java.util.Arrays;

public class CountTripletsWithSum {

    public static int countTriplets(int[] arr, int target) {
        int n = arr.length;
        int count = 0;

        // Step 1: Sort the array
        Arrays.sort(arr);

        // Step 2: Fix one element and use two pointers for the other two
        for (int i = 0; i < n - 2; i++) {
            int left = i + 1;
            int right = n - 1;

            while (left < right) {
                int sum = arr[i] + arr[left] + arr[right];

                if (sum == target) {
                    count++;
                    left++;
                    right--;
                } else if (sum < target) {
                    left++;
                } else {
                    right--;
                }
            }
        }

        return count;
    }

    public static void main(String[] args) {
        int[] arr = {1, 5, 3, 2, 4, 6};
        int target = 10;

        System.out.println("Number of triplets with sum " + target + " = " + countTriplets(arr, target));
    }
}

