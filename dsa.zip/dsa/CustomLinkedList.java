package com.dsa;
// Custom Linked List Implementation
class CustomLinkedList {
    // Node class representing each element of the list
    private static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    private Node head;  // Head (first node) of the linked list

    // Add new node at the end of the list
    public void add(int value) {
        Node newNode = new Node(value);

        if (head == null) {
            head = newNode; // first element
            return;
        }

        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode; // attach at the end
    }

    // Get value at a specific index (0-based)
    public int get(int index) {
        Node current = head;
        int count = 0;

        while (current != null) {
            if (count == index) {
                return current.data;
            }
            count++;
            current = current.next;
        }
        throw new IndexOutOfBoundsException("Index " + index + " out of range");
    }

    // Print all elements
    public void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    // Return size of the list
    public int size() {
        int count = 0;
        Node current = head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }

    // Main method for testing
    public static void main(String[] args) {
        CustomLinkedList list = new CustomLinkedList();

        list.add(10);
        list.add(20);
        list.add(30);
        list.add(40);

        System.out.print("Linked List elements: ");
        list.printList();

        System.out.println("Value at index 2: " + list.get(2));
        System.out.println("Total size: " + list.size());
    }
}

