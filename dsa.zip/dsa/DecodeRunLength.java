package com.dsa;
import java.util.*;
import java.util.*;

public class DecodeRunLength {


    public static String decode(String s) {
        Stack<Integer> countStack = new Stack<>();
        Stack<StringBuilder> resultStack = new Stack<>();
        StringBuilder current = new StringBuilder();
        int num = 0;

        for (char ch : s.toCharArray()) {
            if (Character.isDigit(ch)) {
                // Build the number (handles multi-digit numbers)
                num = num * 10 + (ch - '0');
            }
            else if (Character.isLetter(ch)) {
                // Default count = 1 if no number precedes the letter
                int repeat = (num == 0) ? 1 : num;

                for (int i = 0; i < repeat; i++) {
                    current.append(ch);
                }
                num = 0; // reset for next character
            }
            else if (ch == '(') {
                resultStack.push(current);
                countStack.push(num == 0 ? 1 : num); // default repeat = 1
                current = new StringBuilder();
                num = 0;
            }
            else if (ch == ')') {
                StringBuilder temp = current;
                current = resultStack.pop();
                int repeatTimes = countStack.pop();
                for (int i = 0; i < repeatTimes; i++) {
                    current.append(temp);
                }
            }
        }

        return current.toString();
    }

    public static void main(String[] args) {
        String encoded1 = "A1B2C4";
        String encoded2 = "A2(B3)";
        System.out.println("Input: " + encoded1);
        System.out.println("Output: " + decode(encoded1)); // ABBCCCC

        System.out.println("\nInput: " + encoded2);
        System.out.println("Output: " + decode(encoded2)); // ABB B B ABB B B
    }
}
