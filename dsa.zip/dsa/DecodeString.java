package com.dsa;

import java.util.Stack;

public class DecodeString {

    public String decodeString(String s) {
        Stack<Integer> numStack = new Stack<>();
        Stack<StringBuilder> strStack = new Stack<>();
        int num = 0;
        StringBuilder ans = new StringBuilder();

        for (char c : s.toCharArray()) {
            if (Character.isDigit(c)) {
                // Build multi-digit numbers (e.g., 10[a])
                num = (num * 10) + (c - '0');
            }
            else if (c == '[') {
                // Push current number and string to stacks
                numStack.push(num);
                num = 0;
                strStack.push(ans);
                ans = new StringBuilder();
            }
            else if (c == ']') {
                // Decode the pattern and append to previous string
                String str = ans.toString();
                ans = new StringBuilder(str.repeat(numStack.pop()));
                ans = strStack.pop().append(ans);
            }
            else {
                // Append normal characters
                ans.append(c);
            }
        }

        return ans.toString();
    }

    public static void main(String[] args) {
        DecodeString solution = new DecodeString();

        // Test Case 1
        String input1 = "3[a]2[bc]";
        System.out.println("Input: " + input1);
        System.out.println("Output: " + solution.decodeString(input1));
        // Expected Output: aaabcbc

        // Test Case 2
        String input2 = "3[a2[c]]";
        System.out.println("\nInput: " + input2);
        System.out.println("Output: " + solution.decodeString(input2));
        // Expected Output: accaccacc

        // Test Case 3
        String input3 = "2[abc]3[cd]ef";
        System.out.println("\nInput: " + input3);
        System.out.println("Output: " + solution.decodeString(input3));
        // Expected Output: abcabccdcdcdef

        // Test Case 4
        String input4 = "10[a]";
        System.out.println("\nInput: " + input4);
        System.out.println("Output: " + solution.decodeString(input4));
        // Expected Output: aaaaaaaaaa
    }
}
