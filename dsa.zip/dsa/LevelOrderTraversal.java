package com.dsa;import java.util.*;

class TreeNode3 {
    int val;
    TreeNode3 left, right;

    TreeNode3(int val) {
        this.val = val;
        left = right = null;
    }
}

public class LevelOrderTraversal {
    public static List<List<Integer>> levelOrder(TreeNode3 root) {
        List<List<Integer>> result = new ArrayList<>();
        if (root == null) return result;

        Queue<TreeNode3> queue = new LinkedList<>();
        queue.offer(root);

        while (!queue.isEmpty()) {
            int size = queue.size();
            List<Integer> currentLevel = new ArrayList<>();

            for (int i = 0; i < size; i++) {
                TreeNode3 node = queue.poll();
                currentLevel.add(node.val);

                if (node.left != null) queue.offer(node.left);
                if (node.right != null) queue.offer(node.right);
            }

            result.add(currentLevel);
        }

        return result;
    }

    public static void main(String[] args) {
        // Example: root = [3,9,20,null,null,15,7]
        TreeNode3 root = new TreeNode3(3);
        root.left = new TreeNode3(9);
        root.right = new TreeNode3(20);
        root.right.left = new TreeNode3(15);
        root.right.right = new TreeNode3(7);

        List<List<Integer>> result = levelOrder(root);
        System.out.println(result);
    }
}
