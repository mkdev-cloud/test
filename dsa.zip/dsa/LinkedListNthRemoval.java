package com.dsa;

class LinkedListNthRemoval {
    static class Node {
        int data;
        Node next;
        Node(int d) { data = d; }
    }

    public Node removeNthFromEnd(Node head, int n) {
       Node dummy = new Node(0);
       dummy.next = head;

       Node fast = dummy;
       Node slow = dummy;

       for(int i=0; i<=n; i++)
       {
           fast=fast.next;
       }
       while (fast != null){
           fast = fast.next;
           slow =slow.next;
       }
        slow.next = slow.next.next;
        return dummy.next;
    }

    // Helper: Print linked list
    public void printList(Node head) {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        LinkedListNthRemoval listOps = new LinkedListNthRemoval();

        Node head = new Node(1);
        head.next = new Node(2);
        head.next.next = new Node(3);
        head.next.next.next = new Node(4);
        head.next.next.next.next = new Node(5);

        System.out.print("Original List: ");
        listOps.printList(head);

        head = listOps.removeNthFromEnd(head, 5);

        System.out.print("After Removing 2nd Node from End: ");
        listOps.printList(head);
    }
}
