package com.dsa;
import java.util.*;

class LongestSubstringWithoutRepeating {
    public static int lengthOfLongestSubstring(String s) {
        Map<Character, Integer> map = new HashMap<>();
        int left = 0, maxLength = 0;

        for (int right = 0; right < s.length(); right++) {
            char ch = s.charAt(right);

            // If character already seen, move left pointer
            if (map.containsKey(ch)) {
                left = Math.max(left, map.get(ch) + 1);
            }

            map.put(ch, right);  // update latest index of character
            maxLength = Math.max(maxLength, right - left + 1);
        }

        return maxLength;
    }

    public static void main(String[] args) {
        String s = "abcabcbb";
        System.out.println("Input: " + s);
        System.out.println("Longest Substring Length: " + lengthOfLongestSubstring(s));

        s = "bbbbb";
        System.out.println("\nInput: " + s);
        System.out.println("Longest Substring Length: " + lengthOfLongestSubstring(s));

        s = "pwwkew";
        System.out.println("\nInput: " + s);
        System.out.println("Longest Substring Length: " + lengthOfLongestSubstring(s));
    }
}

