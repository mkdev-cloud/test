package com.dsa;

class TreeNode {
    int val;
    TreeNode3 left, right;

    TreeNode(int val) {
        this.val = val;
        left = right = null;
    }
}

public class MaxDepthExample {
    public static int maxDepth(TreeNode3 root) {
        if (root == null) return 0;
        return 1 + Math.max(maxDepth(root.left), maxDepth(root.right));
    }

    public static void main(String[] args) {
        // Construct the tree from input [3,9,20,null,null,15,7]
        TreeNode3 root = new TreeNode3(3);
        root.left = new TreeNode3(9);
        root.right = new TreeNode3(20);
        root.right.left = new TreeNode3(15);
        root.right.right = new TreeNode3(7);

        int depth = maxDepth(root);
        System.out.println("Maximum Depth of Tree: " + depth);
    }
}
