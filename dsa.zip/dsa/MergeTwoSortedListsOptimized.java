package com.dsa;

class MergeTwoSortedListsOptimized {
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    // Space-optimized merge (in-place)
    public static Node mergeLists(Node list1, Node list2) {
        if (list1 == null) return list2;
        if (list2 == null) return list1;

        // Dummy node for ease of handling head
        Node dummy = new Node(-1);
        Node tail = dummy;

        while (list1 != null && list2 != null) {
            if (list1.data <= list2.data) {
                tail.next = list1;
                list1 = list1.next;
            } else {
                tail.next = list2;
                list2 = list2.next;
            }
            tail = tail.next;
        }

        // Attach the remaining nodes directly (no new allocations)
        tail.next = (list1 != null) ? list1 : list2;

        return dummy.next; // Return head of merged list
    }

    // Helper: create list
    public static Node createList(int[] arr) {
        if (arr.length == 0) return null;
        Node head = new Node(arr[0]);
        Node current = head;
        for (int i = 1; i < arr.length; i++) {
            current.next = new Node(arr[i]);
            current = current.next;
        }
        return head;
    }

    // Helper: print list
    public static void printList(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    // Test
    public static void main(String[] args) {
        int[] arr1 = {1, 3, 5, 7};
        int[] arr2 = {2, 4, 6, 8};

        Node list1 = createList(arr1);
        Node list2 = createList(arr2);

        System.out.print("List1: ");
        printList(list1);
        System.out.print("List2: ");
        printList(list2);

        Node merged = mergeLists(list1, list2);

        System.out.print("Merged Sorted List: ");
        printList(merged);
    }
}

