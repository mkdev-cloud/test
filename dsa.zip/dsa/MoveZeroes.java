package com.dsa;
import java.util.Arrays;

public class MoveZeroes {

    public static void moveZeroes(int[] nums) {
        int insertPos = 0; // position to insert the next non-zero number

        // Step 1: Move all non-zero elements to the front
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] != 0) {
                // Swap without using a temp variable
                System.out.println("i value outside loop  "+i + nums[i]);
                if (i != insertPos) {
                    System.out.println("i value inside loop"+i + nums[i]);

                    nums[i] = nums[i] + nums[insertPos];
                    System.out.println("i value inside loop"+i + nums[i]);
                    nums[insertPos] = nums[i] - nums[insertPos];
                    nums[i] = nums[i] - nums[insertPos];
                }


                insertPos++;
            }
        }
    }

    public static void main(String[] args) {
        int[] nums = {0, 1, 0, 3, 12};
        System.out.println("Before: " + Arrays.toString(nums));

        moveZeroes(nums);

        System.out.println("After:  " + Arrays.toString(nums));
        // Output: [1, 3, 12, 0, 0]
    }
}
