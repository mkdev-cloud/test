package com.dsa;

public class ReverseLinkedList {
   private static class Node{
       int data;
       Node next;

       Node(int data){
           this.data = data;
           this.next = null;

       }
   }
   private Node head;

   public void add(int value){
       Node newNode = new Node(value);
       if(head==null){
           head = newNode;
           return;
       }
       Node current = head;
       while (current.next != null){
           current = current.next;
       }
        current.next = newNode;
   }

   public Node reverse(){
       Node prev = null;
       Node current = head;
       Node nextNode;

       while (current != null){
           nextNode = current.next;  // store next
           System.out.println("// store next  "+ current.data);
           current.next = prev;      // reverse link
           System.out.println("reverse link  "+current.data );
           prev = current;           // move prev ahead
           System.out.println("move prev ahead "+prev.data );
           current = nextNode;       // move current ahead
           System.out.println("move current ahead "+current.data );
       }
       head = prev; // new head
       return head;

   }
    public void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
    public static void main(String[] args) {
        ReverseLinkedList list = new ReverseLinkedList();

        list.add(10);
        list.add(20);
        list.add(30);
        list.add(40);

        System.out.print("Original List: ");
        list.printList();

        list.reverse();

        System.out.print("Reversed List: ");
        list.printList();
    }

}
