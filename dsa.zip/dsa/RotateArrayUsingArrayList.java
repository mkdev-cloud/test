package com.dsa;
import java.util.ArrayList;

public class RotateArrayUsingArrayList {

    public static void rotate(ArrayList<Integer> arr, int k) {
        int n = arr.size();
        if (n == 0) return;

        k = k % n; // Handle cases where k > n
        if (k == 0) return;

        // Step 1: Copy last k elements to temp list
        ArrayList<Integer> temp = new ArrayList<>();
        for (int i = n - k; i < n; i++) {
            temp.add(arr.get(i));
        }
        System.out.println(temp);
        // Step 2: Shift remaining elements to the right
        for (int i = n - 1; i >= k; i--) {
            System.out.println(i +"  "+ k);
            System.out.println(arr.get(i));



            System.out.println(arr.get(i - k));

            arr.set(i, arr.get(i - k));
        }
        System.out.println(arr);


        // Step 3: Copy elements from temp to the beginning
        for (int i = 0; i < k; i++) {
            arr.set(i, temp.get(i));
        }
        System.out.println(arr);

    }

    public static void main(String[] args) {
        ArrayList<Integer> arr = new ArrayList<>();
        arr.add(1);
        arr.add(2);
        arr.add(3);
        arr.add(4);
        arr.add(5);
        arr.add(6);
        arr.add(7);

        int k = 3;

        System.out.println("Original ArrayList: " + arr);
        rotate(arr, k);
        System.out.println("Rotated ArrayList (Right by " + k + "): " + arr);
    }
}
