package com.dsa;

class TreeNode4 {
    int val;
    TreeNode4 left, right;

    TreeNode4(int val) {
        this.val = val;
    }
}


public class SortedArrayToBST {
    public static TreeNode4 sortedArrayToBST(int[] nums) {
        return buildBST(nums, 0, nums.length - 1);
    }

    private static TreeNode4 buildBST(int[] nums, int left, int right) {
        if (left > right) return null;

        int mid = left + (right - left) / 2;  // Avoids overflow
        TreeNode4 node = new TreeNode4(nums[mid]);

        node.left = buildBST(nums, left, mid - 1);
        node.right = buildBST(nums, mid + 1, right);

        return node;
    }

    // Helper function to print in-order traversal
    public static void printInOrder(TreeNode4 root) {
        if (root == null) return;
        printInOrder(root.left);
        System.out.print(root.val + " ");
        printInOrder(root.right);
    }

    public static void main(String[] args) {
        int[] nums = {-10, -3, 0, 5, 9};
        TreeNode4 root = sortedArrayToBST(nums);

        System.out.print("In-order Traversal of BST: ");
        printInOrder(root);
    }
}

