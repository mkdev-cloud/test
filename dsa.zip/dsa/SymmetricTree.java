package com.dsa;

class TreeNode2 {
    int val;
    TreeNode2 left, right;

    TreeNode2(int val) {
        this.val = val;
        left = right = null;
    }
}

public class SymmetricTree {

    public static boolean isSymmetric(TreeNode2 root) {
        if (root == null) return true;
        return isMirror(root.left, root.right);
    }

    private static boolean isMirror(TreeNode2 t1, TreeNode2 t2) {
        if (t1 == null && t2 == null) return true;
        if (t1 == null || t2 == null) return false;

        return (t1.val == t2.val)
                && isMirror(t1.left, t2.right)
                && isMirror(t1.right, t2.left);
    }

    public static void main(String[] args) {
        // ✅ Example 1: Symmetric Tree
        TreeNode2 root1 = new TreeNode2(1);
        root1.left = new TreeNode2(2);
        root1.right = new TreeNode2(2);
        root1.left.left = new TreeNode2(3);
        root1.left.right = new TreeNode2(4);
        root1.right.left = new TreeNode2(4);
        root1.right.right = new TreeNode2(3);

        System.out.println("Is Symmetric (Example 1): " + isSymmetric(root1));


        TreeNode2 root2 = new TreeNode2(1);
        root2.left = new TreeNode2(2);
        root2.right = new TreeNode2(2);
        root2.left.right = new TreeNode2(3);
        root2.right.right = new TreeNode2(3);

        System.out.println("Is Symmetric (Example 2): " + isSymmetric(root2));
    }
}
