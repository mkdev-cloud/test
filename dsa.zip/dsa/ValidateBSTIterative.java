package com.dsa;

import java.util.Stack;

class TreeNode1 {
    int val;
    TreeNode1 left, right;

    TreeNode1(int val) {
        this.val = val;
        left = right = null;
    }
}

public class ValidateBSTIterative {

    public static boolean isValidBST(TreeNode1 root) {
        Stack<TreeNode1> stack = new Stack<>();
        TreeNode1 current = root;
        long prev = Long.MIN_VALUE; // previous node value in inorder traversal

        while (current != null || !stack.isEmpty()) {
            // Go to leftmost node
            while (current != null) {
                stack.push(current);
                current = current.left;
            }

            // Process node
            current = stack.pop();

            // Check if current node value is greater than previous
            if (current.val <= prev) return false;
            prev = current.val;

            // Move to right subtree
            current = current.right;
        }

        return true;
    }

    public static void main(String[] args) {

        TreeNode1 root1 = new TreeNode1(2);
        root1.left = new TreeNode1(1);
        root1.right = new TreeNode1(3);
        System.out.println("Is Valid BST (Example 1): " + isValidBST(root1));


        TreeNode1 root2 = new TreeNode1(5);
        root2.left = new TreeNode1(1);
        root2.right = new TreeNode1(4);
        root2.right.left = new TreeNode1(3);
        root2.right.right = new TreeNode1(6);
        System.out.println("Is Valid BST (Example 2): " + isValidBST(root2));
    }
}

